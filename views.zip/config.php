<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'postgres');
define('DB_PASSWORD', 'postgres');
define('DB_NAME', 'db_todo');
define('DB_PORT', '5432');
