# Latihan PHP: Aplikasi Todolist

## Menjalankan Aplikasi
php -S localhost:8000 -t public

## Logs
- [14/10/2025] Menginisialisasi proyek